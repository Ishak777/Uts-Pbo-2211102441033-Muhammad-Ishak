import greenfoot.*;  

public class GameOver extends Actor
{
    private GreenfootImage image;
    
    public GameOver()
    {
        image = new GreenfootImage("Game Over", 48, Color.WHITE, new Color(0,0,0,0));
        setImage(image);
    }

    public void act() 
    {
        // Tambahkan kode animasi atau logika tambahan di sini jika diperlukan
    }    
}